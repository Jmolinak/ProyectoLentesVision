contenid();
function contenid(){
    $("#contenid").load("contenido.html");
}