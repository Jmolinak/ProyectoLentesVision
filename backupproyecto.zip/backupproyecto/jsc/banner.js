ban();
function ban() {
    $("#banp").load("banner.html");
}