fortmula();
function fortmula(){
    $("#formula").load("formula.html");
}


